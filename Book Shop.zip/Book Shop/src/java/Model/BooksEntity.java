/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author pranesh dorage
 */
public class BooksEntity 
{
    private String isbn;
    private String title;
    private String author;
    private String pub;
    private String dop;
    private String price;

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPub() {
        return pub;
    }

    public void setPub(String pub) {
        this.pub = pub;
    }

    public String getDop() {
        return dop;
    }

    public void setDop(String dop) {
        this.dop = dop;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public BooksEntity(String isbn, String title, String author, String pub, String dop, String price) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.pub = pub;
        this.dop = dop;
        this.price = price;
    }

    public BooksEntity() 
    {
        
    }
    
    public String toString()
    {
        return "ISBN : "+isbn+" Title : "+title+" Author : "+author+" Publisher : "+pub+" Date Of Publishing :"+dop+" Price : "+price;
    }
    
    
}
