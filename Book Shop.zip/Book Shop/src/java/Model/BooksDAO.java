/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author pranesh dorage
 */
public class BooksDAO 
{
    BooksEntity book = new BooksEntity();
    
    private static final String STMT1="SELECT * FROM BOOKS";
    private static final String STMT2="INSERT INTO BOOKS VALUES (?,?,?,?,TO_DATE(?,'DD-MM-YYYY'),?)";
    
    
    Connection cn=null;
    PreparedStatement st=null;
    ResultSet rs=null;
    int num_of_rows=0;
    List list = new LinkedList();
    
    

    // CONNECTING TO THE DATABASE
    public BooksDAO()  
    {
        try
        { 
        Class.forName("oracle.jdbc.OracleDriver");
        }
        catch(ClassNotFoundException e)
        {
            System.out.println(e);
        }
    } 
    
public boolean AddNewBook (String isbn,String title,String author, String pub, String dop,String price) throws SQLException
    {
        
            cn =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","12345");
            st = cn.prepareStatement(STMT2);
            st.setString(1, isbn);
            st.setString(2, title);
            st.setString(3, author);
            st.setString(4, pub);
            st.setString(5, dop);
            st.setString(6, price);
            st.executeUpdate();
            
            st.close();
            cn.close();
            return true;         
    }    
    public //GET ALL RECORDS
    List GetAll()
    {
        try 
        {
            cn =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","12345");
        } 
        catch (SQLException ex) 
        {
            list.add("Database connection could not be established.");
        }
        try 
        {
            
            st = cn.prepareStatement(STMT1);
            rs = st.executeQuery();
                       
            while(rs.next())
            {
              book = new BooksEntity(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));  
              list.add(book.toString());
            }
            
            rs.close();
            st.close();
            cn.close();
        }
        catch (SQLException ex) 
        {
            list.add("Error in fetching data from database.");
            list.add("Please contact the admin asap.");
        }
        return list;
    }
    
}
