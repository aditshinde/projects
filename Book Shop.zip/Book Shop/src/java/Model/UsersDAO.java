/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author pranesh dorage
 */
public class UsersDAO 
{
    
    private static final String STMT1="SELECT * FROM USERS WHERE EMAIL=? AND PASS =?";
    private static final String STMT2="INSERT INTO USERS VALUES (?,?,?,?,?)";
    
    Connection cn=null;
    PreparedStatement st=null;
    ResultSet rs=null;
    int num_of_rows=0;
    
    

    // CONNECTING TO THE DATABASE
    public UsersDAO()  
    {
        try
        { 
        Class.forName("oracle.jdbc.OracleDriver");
        }
        catch(ClassNotFoundException e)
        {
            System.out.println(e);
        }
    } 
    
    public boolean CheckLogin (String email,String pass) throws SQLException
    {
        
            cn =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","12345");
            st = cn.prepareStatement(STMT1);
            st.setString(1, email);
            st.setString(2, pass);
            rs = st.executeQuery();
            int i=0;
            while(rs.next())
            {
              i++;
            }
            rs.close();
            st.close();
            cn.close();
        
            if(i==1)
            {
                return true;
            }
            else
            {
                return false;
            }            
            
            
    }
    
    public boolean CreateNewLogin (String fname,String lname, String mobile, String email,String pass) throws SQLException
    {
        
            cn =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","12345");            st = cn.prepareStatement(STMT2);
            st.setString(1, fname);
            st.setString(2, lname);
            st.setString(3, mobile);
            st.setString(4, email);
            st.setString(5, pass);
            st.executeUpdate();
            
            st.close();
            cn.close();
            return true;         
    }
    
    
}
