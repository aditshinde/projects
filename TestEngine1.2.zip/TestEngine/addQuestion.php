<?PHP
session_start();
$fname=$lname=$id=$email=''; 
$ques=$a=$b=$c=$d=$ans='';
$error='default';
$success='default';
    if(isset($_SESSION['id']))
    {
        $id=$_SESSION['id'];
        $email=$_SESSION['email'];
        $fname=$_SESSION['fname'];
        $lname=$_SESSION['lname'];
        if(isset($_SESSION['ques']))
        {
        $ques=$_SESSION['ques'];    
        $a=$_SESSION['a'];
        $b=$_SESSION['b'];
        $c=$_SESSION['c'];
        $d=$_SESSION['d'];
        $ans=$_SESSION['ans'];
        }
        if(isset($_SESSION['error']))
        {
        $error=$_SESSION['error'];
        }
        if(isset($_SESSION['success']))
        {
        $success=$_SESSION['success'];    
        }
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Add Question</title>
        <link href="data/css/css.css" rel="stylesheet" type="text/css"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>    </head>
    <body>  
    <?php 
        include 'header.html';
        include 'admin_menu.html';
        
    ?>
       
    <article>
        <span>Hi!<?php echo $fname." ".$lname;?></span>
        <h2>Add New Question</h2>
        <form action="AdminAddQuestion.php" method="POST">

        <table>
            <tr>
                <td>
                    Question
                </td>
                <td>
                    <textarea class="resizable" name="ques" rows="5" cols="100" <?PHP echo $ques;?> required></textarea>
                </td>
            </tr>
            <tr>
                <td>
                    Option A:
                </td>
                <td>
                    <textarea class="resizable" type="text" name="a" rows="5" cols="100" value='<?PHP echo $a;?>' required></textarea>
                </td>
            </tr>
            <tr>
                <td>
                    Option B:
                </td>
                <td>
                    <textarea class="resizable" type="text" name="b"  rows="5" cols="100"  value="<?PHP echo $b;?>"  required></textarea>
                </td>
            </tr>
            <tr>
                <td>
                    Option C:
                </td>
                <td>
                    <textarea class="resizable" type="text" name="c" rows="5" cols="100"  value="<?PHP echo $c;?>" required></textarea>
                </td>
            </tr>
            <tr>
                <td>
                    Option D:
                </td>
                <td>
                    <textarea class="resizable" type="text" name="d" rows="5" cols="100"  value="<?PHP echo $d;?>" required></textarea>
                </td>
            </tr>
            <tr>
                <td>
                    Answer:
                </td>
                <td>
                    <input type="text"  name="ans" size="1" value="<?PHP echo $ans;?>" required />
                </td>
            </tr>
            <tr>
                <td>
                    <input class='button' type="reset" value="Reset" />
                </td>
                <td>
                    <input class='button' type="submit" value="Add Question" />
                </td>
            </tr>
        </table>

        </form>
        <?PHP
        if(strcasecmp($error,'default')!=0)
        {   
            echo '<div class="error">'.$error.'</div>';
        }
        if(strcasecmp($success,'default')!=0)
        {   
            echo '<div class="success">'.$success.'</div>';
        }
        ?>

    </article>
 <?php
 include 'footer.php';
 ?>
    </body>
</html>
