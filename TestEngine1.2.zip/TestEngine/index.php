<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link href="data/css/css.css" rel="stylesheet" type="text/css"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    </head>
    
    <?php
    include 'header.html';
    include 'main_menu.html';
    ?>
    <body>
        <div class="container">
        <article>
                <h2>Welcome to CSI Test Engine 1.0</h2>
                <p>
                    <a href="register.php">Register</a>
                    or
                    <a href="login.php">Login</a>
                    to continue.
                </p>
        </article>
        </div>
    </body>
    <?php
        include 'footer.php';
    ?>
</html>
