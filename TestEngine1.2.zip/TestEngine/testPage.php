<?php
session_start();
$fname=$lname=$id=$email=$mobile=$table="";
$ques=$a=$b=$c=$d=$ans="";
$qno;$srno;
$error="";
if(isset($_SESSION['email']))
    {
        $id=$_SESSION['id'];
        $email=$_SESSION['email'];
        $fname=$_SESSION['fname'];
        $lname=$_SESSION['lname'];
        $mobile=$_SESSION['mobile'];
        $srno=$_SESSION['srno'];
        $maxQues=$_SESSION['maxQues'];
    }
    else 
    {
        header('Location: Logout.php');
    }
$host="localhost";
$port=12348;
$socket="";
$user="root";
$password="12345";
$dbname="csi";
$table="MOBILE_".$mobile;

$con = new mysqli($host, $user, $password, $dbname, $port, $socket)
	or die ('Could not connect to the database server' . mysqli_connect_error());
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>TEST PAGE</title>
        <link href="data/css/css.css" rel="stylesheet" type="text/css"/>
        <script src="data/javaScript/jquery-2.1.4.js" type="text/javascript"></script>
        <script>
        setInterval(function(){
            $("#timer").load("Clock.php");
        },1000);
        </script>
    </head>
    <body>
        <script>
        $(document).ready(function(){
        $("#slide").click(function(){
        $("div").children("#testNavBtn").fadeToggle("fast");
        $("div").children("#testSubmitBtn").fadeToggle("fast");
    });
});
        
        
        </script>
<?php
$getQno="SELECT QNO FROM ".$table." WHERE SRNO=".$srno;
$query = $con->query($getQno);

if($query!==FALSE)
{
    $row = $query->fetch_array();
    $qno=$row[0];
}
else
{
echo "<script>alert(".$con->error.")</script>";
header("Location: testPage.php");
}



$stmt = $con->prepare("SELECT QUES,A,B,C,D FROM QUESTIONS WHERE QNO = ?");
$stmt->bind_param("s", $qno);
$stmt->execute();
$stmt->bind_result($ques,$a,$b,$c,$d);
$stmt->fetch();

?>
<?php 
include 'header.html';
include 'user_menu.html';
?>
<div id="timer"></div>       
<article>
    
    <h2>Question <?PHP echo $srno;?></h2>
    <?PHP echo $ques;?>
    <form action="TestMain.php" method="POST">
        <table>
            <tbody>
                <tr>
                    <td>
                        <input type="radio" name="choice" value="a" /><?PHP echo $a;?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="radio" name="choice" value="b" /><?PHP echo $b;?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="radio" name="choice" value="c" /><?PHP echo $c;?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="radio" name="choice" value="d" /><?PHP echo $d;?>
                    </td>
                </tr>
            </tbody>
        </table>

        <div class="testNav">
        <input type="reset" class="button" id="testNavBtn" value="Reset" />
        <input type="submit" class="button"  id="testNavBtn"  name="prev" value="< Previous Question" />
        <?PHP echo '<input type="submit" id="testNavBtn" class="button"  name="first" value="1" />'?>
        <span id="testNavBtn">...</span>
        <?PHP 
        if(($srno-2)>1)
        {
            echo '<input type="submit"  id="testNavBtn" class="button"  name="preprev" value='.($srno-2).' />';
        }
        ?>
        <?PHP echo '<input type="button" id="testNavBtn"  class="button"  name="srno" value='.$srno.' />'?>
        <?PHP 
        if(($srno+2)<$maxQues)
        {
            echo '<input type="submit"  id="testNavBtn" class="button"  name="postnext" value='.($srno+2).' />';
        }
        ?>
        <span id="testNavBtn">...</span>
        <?PHP echo '<input type="submit" id="testNavBtn" class="button"  name="last" value='.$maxQues.' />'?>
        <input type="submit" class="button" id="testNavBtn"   name="next" value="Next Question >" />
        <input type="submit" class="button"  id="testSubmitBtn"  name="submit" value="Submit" />
        <input type="button" class="button" id="slide"  value="&#x2194" />
        </div>
    </form>
    
    
<?PHP
if(isset($_SESSION['error']))
{
    $error=$_SESSION['error'];
    echo "<div class=\"error\">"
    .$error.""
            . "</div>";
}
?>  
</article>
<?php
include 'footer.php';
?>
        
    </body>
</html>
