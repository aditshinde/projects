<?PHP
session_start();
$fname=$lname=$id=$email='';
$error=0;
    if(isset($_SESSION['id']))
    {
        $id=$_SESSION['id'];
        $email=$_SESSION['email'];
        $fname=$_SESSION['fname'];
        $lname=$_SESSION['lname'];
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>User Portal</title>
        <link href="data/css/css.css" rel="stylesheet" type="text/css"/>
        <script src="data/JavaScript/jquery-1.11.3.js" type="text/javascript"></script>
        <script src="data/JavaScript/jquery-2.1.4.js" type="text/javascript"></script>
    </head>
    <body>
        <?php 
            include 'header.html';
        ?>
         
            <article>
                <span>Hi! <?php echo $fname." ".$lname;?></span>
                <h2>Instructions</h2>
                <p>
                    Please read these instructions carefully.
                    <br/>I repeat Please read all the instructions carefully.
                </p>
                <ol type="1">
                    <li>The test will start immediately after you press the START TEST button.</li>
                    <li>The test will end automatically in 30 minutes.</li>
                    <li>The test consists of objective questions with 4 options.</li>
                    <li>You can end the test at any point of time by clicking the SUBMIT button.</li>
                    <li>Do not try to open any new window or tab.</li>
                    <li>If you do so the test will end and you will be disqualified on the spot.</li>
                    <li>The questions will be generated on a random basis.</li>
                    <li>You are under supervision. If caught cheating you will be disqualified.</li>
                    <li>Don't try to cheat the system rather try to beat it.</li>
                    <li>Lastly, I would like to say ALL THE BEST!</li>
                </ol>
                <form action="TestGenerator.php">
                    <input class="button" type="submit" value="Start Test" />
                </form>
                <?PHP
                if(isset($_SESSION['error']))
                {
                    $error=$_SESSION['error'];
                    echo "<div class=\"error\">"
                    .$error.""
                            . "</div>";
                }
                ?>                               
            </article>
 <?php
 include 'footer.php';
 ?>
    </body>
</html>
