<?php
session_start();
$fname=$lname=$id=$email=$mobile=$table="";
$ques=$a=$b=$c=$d=$ans="";
$qno;$srno;$maxQues;
$error="";
if(isset($_SESSION['email']))
    {
        $id=$_SESSION['id'];
        $email=$_SESSION['email'];
        $fname=$_SESSION['fname'];
        $lname=$_SESSION['lname'];
        $mobile=$_SESSION['mobile'];
        $srno=$_SESSION['srno'];
        $maxQues=$_SESSION['maxQues'];
        $score=$_SESSION['score'];
    }
?>    
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Register</title>
        <link href="data/css/css.css" rel="stylesheet" type="text/css"/>
        <script src="data/javaScript/jquery-2.1.4.js" type="text/javascript"></script>
    </head>
    <body>
        <?php 
            include 'header.html';
        ?>       
            <article>
                <span>Hi! <?php echo $fname." ".$lname;?></span>
                <div class="centered">
                <h2>Your Score</h2>
                <h1><?PHP echo $score;?></h1>
                <form action="Logout.php">
                    <input type="submit" class="button"  value="Logout">
                </form>
                </div>
                <?PHP
                if(isset($_SESSION['error']))
                {
                    $error=$_SESSION['error'];
                    echo "<div class=\"error\">"
                    .$error.""
                            . "</div>";
                }
                ?>  
            </article>
        
 <?php
 include 'footer.php';
 ?>
    </body>
</html>