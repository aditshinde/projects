<?php
session_start();
date_default_timezone_set("Asia/Kolkata");
$testDuration=1;
if(isset($_SESSION['startTime']))
{
$getStartTime=$_SESSION['startTime'];
}
else
{
$getStartTime=date("h:i:s");    
}




$startTime = explode(":", $getStartTime);

//Find Start Time
$startSecs=($startTime[0]*60*60)+($startTime[1]*60)+($startTime[2]);

if(isset($_SESSION['endTime']))
{
$endSecs=$_SESSION['endTime'];
}
else
{
//Find End Time by adding test duration
$endSecs=$startSecs+($testDuration*60);
$_SESSION['endTime']=$endSecs;
}

//Calculate Test End Time

$getCurrentTime=date("h:i:s");
$currentTime = explode(":", $getCurrentTime);
$currentSecs=($currentTime[0]*60*60)+($currentTime[1]*60)+($currentTime[2]);

$remainingSecs=$endSecs-$currentSecs;

$remainTime[0]=$remainingSecs/3600;
$remainingSecs=$remainingSecs%3600;
$remainTime[1]=$remainingSecs/60;
$remainingSecs=$remainingSecs%60;
$remainTime[2]=$remainingSecs;


//Calucute Test Remaining Time
$endTimeSecs=$endSecs;

$endTime[0]=$endTimeSecs/3600;
$endTimeSecs=$endTimeSecs%3600;
$endTime[1]=$endTimeSecs/60;
$endTimeSecs=$endTimeSecs%60;
$endTime[2]=$endTimeSecs;


if((int)$remainTime[0]<=0 && (int)$remainTime[1]<=0 && (int)$remainTime[2]<=0)
{
    echo '<script> $(document).ready(function(){
  $("#testSubmitBtn").trigger("click");
});</script>';
}

echo '<table class="timer"><tr>';
echo '<td>Start: '.$getStartTime.'</td>';
echo '<td>Remaining: '.(int)$remainTime[0].":".(int)$remainTime[1].":".$remainTime[2].'</td>';
echo '<td>End: '.(int)$endTime[0].":".(int)$endTime[1].":".$endTime[2].'</td>';
echo '</tr></table>';

