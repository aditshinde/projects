<?php
if(session_status()==2)session_destroy();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Login</title>
        <link href="data/css/css.css" rel="stylesheet" type="text/css"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    </head>
    <body>
        <?php
        include 'header.html';
        include 'main_menu.html';
        $error=0;
        if(isset($_GET['error']))
                {
                    $error=$_GET['error'];
                }       
        ?>
        <div class="container">
            <article>
                <h2>Login</h2>
                <form action="LoginCheck.php" method="post">
                    <table>
                        <?php
                        if($error==1)
                        {
                            echo '
                                <tr>
                            <td></td>    
                            <td>
                                <div class=\'error\'>
                                Incorrect Email/Password!
                                </div>
                            </td>
                            </tr>';
                        }
                        ?>
                        <tr>
                            <td>
                                Email Id:
                            </td>
                            <td>
                                <input type="email" name="email" required />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Password:
                            </td>
                            <td>
                                <input type="password" name="pass" required />
                            </td>
                        </tr>
                        
                        <tr>
                            <td>
                                <input class="button" type="reset" value="Reset" />
                            </td>
                            <td>
                                <input class="button" type="submit" value="Login" />
                            </td>
                        </tr>
                        
                    </table>

                </form>
                
                
            </article>

        </div>
       
        <?php
        include 'footer.php';
        ?>
    </body>
</html>
