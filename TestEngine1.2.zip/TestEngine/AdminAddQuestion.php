<?PHP
session_start();
$fname=$lname=$id=$email=''; 
$ques=$a=$b=$c=$d=$ans='';

    if(isset($_SESSION['id']))
    {
        $id=$_SESSION['id'];
        $email=$_SESSION['email'];
        $fname=$_SESSION['fname'];
        $lname=$_SESSION['lname'];
        if(isset($_SESSION['ques']))
        {
            $ques=$_SESSION['ques'];    
            $a=$_SESSION['a'];
            $b=$_SESSION['b'];
            $c=$_SESSION['c'];
            $d=$_SESSION['d'];
            $ans=$_SESSION['ans'];
        }
        if(isset($_POST['ques']))
        {
            $ques= filter_var($_POST['ques'], \FILTER_SANITIZE_STRING);
            $a=\filter_var($_POST['a'], \FILTER_SANITIZE_STRING);
            $b=\filter_var($_POST['b'], \FILTER_SANITIZE_STRING);
            $c=\filter_var($_POST['c'], \FILTER_SANITIZE_STRING);
            $d=\filter_var($_POST['d'], \FILTER_SANITIZE_STRING);
            $ans=\filter_var($_POST['ans'], \FILTER_SANITIZE_STRING);
            $ques=nl2br($ques);
            $a=  nl2br($a);
            $b=  nl2br($b);
            $c=  nl2br($c);
            $d=  nl2br($d);
            $ans=strtolower($ans);
        }
    }
    
$host="localhost";
$port=12348;
$socket="";
$user="root";
$password="12345";
$dbname="csi";

$con = new mysqli($host, $user, $password, $dbname, $port, $socket)
	or die ('Could not connect to the database server' . mysqli_connect_error());

$stmt = $con->prepare("INSERT INTO QUESTIONS (ques,a,b,c,d,ans) VALUES (?,?,?,?,?,?)");
$stmt->bind_param("ssssss", $ques, $a, $b, $c, $d, $ans);

if($stmt->execute()===TRUE)
{
    $_SESSION['success']='Question Successfully Added...';
    header('Location: addQuestion.php');
}
else
{
    $_SESSION['error']=$con->error;
    header('Location: addQuestion.php');
}
$con->close();