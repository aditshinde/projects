<?php
session_start();
$fname=$lname=$id=$email=$mobile=$table="";
$ques=$a=$b=$c=$d=$ans="";
$qno;$srno;$maxQues;
$error="";
if(isset($_SESSION['email']))
    {
        $id=$_SESSION['id'];
        $email=$_SESSION['email'];
        $fname=$_SESSION['fname'];
        $lname=$_SESSION['lname'];
        $mobile=$_SESSION['mobile'];
        $srno=$_SESSION['srno'];
        $maxQues=$_SESSION['maxQues'];
        $_SESSION['error']="";
    }
    else 
    {
        header('Location: Logout.php');
    }
$host="localhost";
$port=12348;
$socket="";
$user="root";
$password="12345";
$dbname="csi";
$table="MOBILE_".$mobile;

$con = new mysqli($host, $user, $password, $dbname, $port, $socket)
	or die ('Could not connect to the database server' . mysqli_connect_error());

if(isset($_POST['choice']))
{
$ans=$_POST['choice'];
$query="UPDATE ".$table." SET ANS='".$ans."' WHERE SRNO=".$srno;
$con->query($query);
}

if(isset($_POST['prev']))
{
    if($srno>1)
    {
        $_SESSION['srno']=--$srno;
    }
    header("Location: testPage.php");
}
else if(isset($_POST['next']))
{
    if($srno<$maxQues)
    {
        $_SESSION['srno']=++$srno;
    }
    header("Location: testPage.php");
}
else if(isset($_POST['first']))
{
    $_SESSION['srno']=1;
    header("Location: testPage.php");
}
else if(isset($_POST['preprev']))
{
    $_SESSION['srno']=$srno-2;
    header("Location: testPage.php");
}else if(isset($_POST['postnext']))
{
    $_SESSION['srno']=$srno+2;
    header("Location: testPage.php");
}
else if(isset($_POST['last']))
{
    $_SESSION['srno']=$maxQues;
    header("Location: testPage.php");
}
else if(isset($_POST['submit']))
{
        $getScore="SELECT QUESTIONS.ANS,".$table.".ANS FROM QUESTIONS,".$table." WHERE  QUESTIONS.ANS =".$table.".ANS";

$result = $con->query($getScore);

if($result!==FALSE)
{
    $score=mysqli_num_rows($result);
    $_SESSION['score']=$score;
    
    $setScore="UPDATE PARTICIPANTS SET SCORE=".$score." WHERE EMAIL='".$email."'";
    if($con->query($setScore)===FALSE)
    {
        $_SESSION['error']="Score Saving Failed.";
        header("Location: testPage.php");
        exit();
    }
    
    $freeDb="DROP TABLE ".$table;
    if($con->query($freeDb)===FALSE)
    {
        $_SESSION['error']="Table not dropped.";
        header("Location: testPage.php");
        exit();
    }
    
    header("Location: finalScore.php");
}
else
{
    $_SESSION['error']="Score Calculation Failed.";
    header("Location: testPage.php");
    
}

}
else
{
    $_SESSION['error']="Something went wrong. Try clicking again.";
    header("Location: testPage.php");
}