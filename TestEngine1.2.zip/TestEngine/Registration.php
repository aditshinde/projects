<?php
$host="localhost";
$port=12348;
$socket="";
$user="root";
$password="12345";
$dbname="csi";

$con = new mysqli($host, $user, $password, $dbname, $port, $socket)
	or die ('Could not connect to the database server' . mysqli_connect_error());

$error = '';
$fname= filter_var($_POST['fname'], \FILTER_SANITIZE_STRING);
$lname=\filter_var($_POST['lname'], \FILTER_SANITIZE_STRING);
$year=\filter_var($_POST['year'], \FILTER_SANITIZE_STRING);
$col=\filter_var($_POST['col'], \FILTER_SANITIZE_STRING);
$mobile=\filter_var($_POST['mobile'], \FILTER_SANITIZE_STRING);
$email=\filter_var($_POST['email'], \FILTER_SANITIZE_STRING);
$pass=\filter_var($_POST['pass'], \FILTER_SANITIZE_STRING);
$score=0;

// prepare and bind
$stmt = $con->prepare("INSERT INTO PARTICIPANTS VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssssi", $fname, $lname, $year, $col, $mobile, $email, $pass, $score);


if ($stmt->execute() === TRUE) 
    {
    header('Location: login.php');
    } 
else if(strpos($con->error, 'Duplicate') !== false)
    {
    header('Location: login.php');
    }
else
{
    $error = "Error: " . $con->error;
}
$con->close();
    


