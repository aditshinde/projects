<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Register</title>
        <link href="data/css/css.css" rel="stylesheet" type="text/css"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>    </head>
    <body>
        <?php 
            include 'header.html';
            include 'main_menu.html';
            $fname=$lname=$year=$col=$mobile=$email="";
            
         ?>
        <div class="container">
            <article>
                <h2>Registration Form</h2>
                <form action="Registration.php" method="POST">
                <table>
                    <tr>
                        <td>
                            First Name:
                        </td>
                        <td>
                            <input type="text" name="fname" value="<?php echo $fname?>" required />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Last Name:
                        </td>
                        <td>
                            <input type="text" name="lname" value="<?php echo $lname?>"  />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Year:
                        </td>
                        <td>
                            <select name="year">
                                <option value='FE'>FE</option>
                                <option value='SE'>SE</option>
                                <option value='TE'>TE</option>
                                <option value='BE'>BE</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            College:
                        </td>
                        <td>
                            <input type="text" name="col" value="<?php echo $col?>" required />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Mobile:
                        </td>
                        <td>
                            <input type="number" name="mobile" min="1000000000" max="9999999999" value="<?php $mobile?>" required />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Email:
                        </td>
                        <td>
                            <input type="email" name="email" value="<?php echo $email?>" required />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Password:
                        </td>
                        <td>
                            <input type="password" name="pass" required />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <input class='button' type="reset" value="Reset" />
                        </td>
                        <td>
                            <input class='button' type="submit" value="Register" />
                        </td>
                    </tr>
                </table>
                
                </form>
                
            </article>
        </div>
 <?php
 include 'footer.php';
 ?>
    </body>
</html>
