<?php
    session_start();
    $fname=$lname=$id=$email='';      
    if(isset($_SESSION['id']))
    {
        $id=$_SESSION['id'];
        $email=$_SESSION['email'];
        $fname=$_SESSION['fname'];
        $lname=$_SESSION['lname'];
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Admin Portal</title>
    <link href="data/css/css.css" rel="stylesheet" type="text/css"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    </head>
    
    <?php
    include 'header.html';
    include 'admin_menu.html';
    ?>
    <body>
        <div class="container">
        <article>
            <span>Hi! <?php echo $fname." ".$lname;?></span>
            <h2>Welcome to Administration Portal</h2>
            <p>
                Administrator Information
            </p>
            <table>
                    <tr>
                        <td>
                            First Name:
                        </td>
                        <td>
                            <?php echo $fname?>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Last Name:
                        </td>
                        <td>
                            <?php echo $lname?>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Email:
                        </td>
                        <td>
                            <?php echo $email?>
                        </td>
                    </tr>
            </table>
        </article>
        </div>
    </body>
    <?php
        include 'footer.php';
    ?>
</html>
