<?php
session_start();
$fname=$lname=$id=$email=$mobile=$table='';
$ques=$a=$b=$c=$d=$ans="";
$qno=0;
$error="";
    if(isset($_SESSION['email']))
    {
        $id=$_SESSION['id'];
        $email=$_SESSION['email'];
        $fname=$_SESSION['fname'];
        $lname=$_SESSION['lname'];
        
    }
    else 
    {
        header('Location: Logout.php');
    }

    
$host="localhost";
$port=12348;
$socket="";
$user="root";
$password="12345";
$dbname="csi";

$con = new mysqli($host, $user, $password, $dbname, $port, $socket)
	or die ('Could not connect to the database server' . mysqli_connect_error());

$stmt1=$con->prepare("SELECT MOBILE FROM PARTICIPANTS WHERE EMAIL=?");
$stmt1->bind_param("s", $email);
if($stmt1->execute()===TRUE)
{
    $stmt1->bind_result($mobile);
    $stmt1->fetch();
    $_SESSION['mobile']=$mobile;
    $stmt1->close();
}
else
{
    $stmt1->close();
    
    $_SESSION['error']=$con->error;
    header("Location: userPortal.php");
}

$table="MOBILE_".$mobile;
$queryCreate="CREATE TABLE ".$table."(srno INT not null primary key auto_increment,
        qno INT not null,
        ans TEXT)";

if($con->query($queryCreate)!==TRUE)
{
    $_SESSION['error']=$con->error;
    header("Location: Logout.php");
    exit();
}

$stmt2=$con->prepare("SELECT QNO FROM QUESTIONS ORDER BY QNO DESC");
if($stmt2->execute()===TRUE)
{
$stmt2->bind_result($qno);
$stmt2->fetch();
$stmt2->close();
}
else
{
    $stmt2->close();
    
    $_SESSION['error']=$con->error;
    header("Location: userPortal.php");
    exit();
}

$numbers = range(1, $qno);
shuffle($numbers);


foreach($numbers as $num)
{
   $queryInsert="INSERT INTO ".$table."(QNO) VALUES (".$num.")" ;
   if($con->query($queryInsert)!==TRUE)
   {
    $_SESSION['error']=$con->error;
    header("Location: userPortal.php");      
   }
}
$_SESSION['maxQues']=$qno;
$_SESSION['srno']=1;
date_default_timezone_set("Asia/Kolkata");
$_SESSION['startTime']=date("h:i:s");
$con->close();

header("Location: testPage.php");