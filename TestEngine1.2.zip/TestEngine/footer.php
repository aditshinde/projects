<footer>
<?php
echo "Copyright &copy; 2013-" .date("Y")." AKL";
?>
</footer>