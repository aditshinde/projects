<?php
session_start();
$host="localhost";
$port=12348;
$socket="";
$user="root";
$password="12345";
$dbname="csi";

$con = new mysqli($host, $user, $password, $dbname, $port, $socket)
	or die ('Could not connect to the database server' . mysqli_connect_error());

$error = 0;
$adminEmail="aditshinde@gmail.com";
$adminPass="12345";

$email=\filter_var($_POST['email'], \FILTER_SANITIZE_STRING);
$pass=\filter_var($_POST['pass'], \FILTER_SANITIZE_STRING);

$fname=$lname=$resultEmail=$resultPass='';

$stmt = $con->prepare('SELECT FNAME,LNAME,EMAIL,PASS FROM PARTICIPANTS WHERE EMAIL = ? AND PASS = ?');
$stmt->bind_param("ss", $email, $pass);
$stmt->execute();
$stmt->bind_result($fname,$lname,$resultEmail,$resultPass);
$stmt->fetch();
$stmt->close();
$con->close();

if (strcasecmp($adminEmail,$email)== 0 && strcasecmp($adminPass,$pass)== 0)
{
    $_SESSION['id']=  session_id();
    $_SESSION['fname']=$fname;
    $_SESSION['lname']=$lname;
    $_SESSION['email']=$email;
    header('Location: adminPortal.php');
}
else if (strcasecmp($resultEmail,$email)== 0 && strcasecmp($resultPass,$pass)== 0)
{
    $_SESSION['id']=  session_id();
    $_SESSION['fname']=$fname;
    $_SESSION['lname']=$lname;
    $_SESSION['email']=$email;
    header('Location: userPortal.php');
}
else
{
    header('Location: login.php?error=1');
}

