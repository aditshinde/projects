<?php
session_start();
require 'Model/User.php';
$fname=$lname= $dob= $location= $mobile= $email=$profilePic=$id=$profile=null;

if(isset($_GET['self']))
{
    unset($_SESSION['profile']);
}

if(isset($_SESSION['profile']))
{
    $profile=$_SESSION['profile'];
    
    $id = array_pop($profile);
    $fname=array_pop($profile);
    $lname=array_pop($profile);
    $dob=array_pop($profile);
    $location=array_pop($profile);
    $mobile=array_pop($profile);
    $email=array_pop($profile);
    $profilePic= array_pop($profile);
    
}
else
{
    $id = $_SESSION['id'];
    $fname=$_SESSION['fname'];
    $lname=$_SESSION['lname'];
    $dob=$_SESSION['dob'];
    $location=$_SESSION['location'];
    $mobile=$_SESSION['mobile'];
    $email=$_SESSION['email'];
    $profilePic=$_SESSION['profilePic'];
}


?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Profile</title>
        <link href="View/style.css" rel="stylesheet" type="text/css"/>
        <?php
        include 'fancybox.html';
        ?>
    </head>
    <body>
        <?php
        include 'header.php';
        
        if(isset($_SESSION['id'])&&isset($_SESSION['profile']))
        {
            include 'user_menu.php';
        }
        elseif (isset($_SESSION['id'])) 
        {
            include 'user_menu.php';
        }
        else
        {
            include 'main_menu.php';
        }
        ?>
        <br/>
        <div class="content">
            <div id="profilePic">
            <img name="profilePic"  src="
                <?php
                    if($profilePic!=null)
                    {
                        echo 'upload/'.$profilePic;
                    }
                    else
                        echo 'images/Personal.png';
                ?>" width="160" height="160" alt="Profile Picture" />
            <img src="" alt=""/>
            </div>
            <div id="profileDesc">
                <p>
                <?php echo $fname.' '.$lname;?><br/>
                <?php echo $dob;?><br/>
                <?php echo $location;?><br/>
                <?php echo $mobile;?><br/>
                <?php echo $email;?><br/>
                </p>
            </div>
            
            
        </div>
        <?php
                include 'footer.php';
        ?>
    </body>
</html>
