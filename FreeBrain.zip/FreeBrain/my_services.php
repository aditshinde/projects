<?php
require 'Model/Service.php';
session_start();

if(isset($_SESSION['id']))
{
    $id = $_SESSION['id'];
    $fname=$_SESSION['fname'];
    $lname=$_SESSION['lname'];
    $dob=$_SESSION['dob'];
    $location=$_SESSION['location'];
    $mobile=$_SESSION['mobile'];
    $email=$_SESSION['email'];
    $profilePic=$_SESSION['profilePic'];
    
    $serviceArray = $_SESSION['service'];
    
    $no_of_rows=count($serviceArray);
    $service=new Service();
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>TheFreeBird-My Services</title>
        <link href="View/style.css" rel="stylesheet" type="text/css"/>
        <?php
        include 'fancybox.html';
        ?>
    </head>
    <body>
        <?php
        include 'header.php';
        ?>
        <?php
        include 'user_menu.php';
        ?>
        <div class="content">
            <h1>My Services</h1>
            <table width="90%" class="table" id='left_align'>
            <tr>
    <th scope="col">Title</th>
    <th scope="col">Type</th>
    <th scope="col">Specialization</th>
    <th scope="col">Description</th>
    <th scope="col">Image</th>
    <th scope="col">Video</th>
    <th scope="col">Price</th>
    <th scope="col">Delete</th>
  </tr>   
            <?php
            for($i=0;$i<$no_of_rows;$i++)
            {
                $service=array_pop($serviceArray);
                echo '<tr>';
                echo '<td>'. $service->title.'</td>';
                echo '<td>'. $service->type.'</td>';
                echo '<td>'. $service->special.'</td>';
                echo '<td>'. $service->desc.'</td>';
                echo '<td>';               
                echo '<a class="fancybox" href="'.$service->image.'"><img src="images/Image.png"  width="32" height="32"/></a>';
                echo '</td>';
                echo '<td>';
                echo '<a class="fancybox-media" href="'.$service->video.'"><img src="images/Video.png"  width="32" height="32"/></a>';                
                echo '</td>';
                echo '<td>'. $service->price.'</td>';
                echo '<td>'
                . '<a href="Controller/DeleteService.php?sid='.$service->sid.'" >'
                        . '<img src="images/delete.ico" height="32" width="32"/></a></td>';
                
                echo '</tr>';
              
            }
            
            ?>
            </table>
            
            
        
            
        </div>        
        <?php
        include 'footer.php';
        ?>
    </body>
</html>
