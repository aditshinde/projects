<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link href="View/style.css" rel="stylesheet" type="text/css"/>
        <title>TheFreeBird-Register</title>
    </head>
    <body>
        <?php
        include 'header.php';
        include 'main_menu.php';
        $error=0;
        if(isset($_GET['error']))
                {
                    $error=$_GET['error'];
                }
        ?>
        <div class="content">
            
            <form id="register" enctype="multipart/form-data" 
                  name="register" method="post" action="Controller/Registration.php">

<table width="100%" border="0">
  <tr>
    <td width="20%">First Name:</td>
    <td width="80%"><input type="text" name="fname" id="fname" 
                           placeholder="Harry" required="required" /></td>
  </tr>
  <tr>
    <td>Last Name:</td>
    <td><input type="text" name="lname" placeholder="Potter" id="lname"  /></td>
  </tr>
  <tr>
    <td>Date of Birth:</td>
    <td><input type="date" name="dob" min="1950-01-01" id="dob" required="required" /></td>
  </tr>
  <tr>
    <td>City:</td>
    <td><input type="text" name="location" placeholder="Mumbai" id="location" /></td>
  </tr>
  <tr>
    <td>Mobile:</td>
    <td><input type="number" name="mobile" id="mobile" placeholder="9619875462" min="1000000000" max="9999999999" required="required"/></td>
  </tr>
  <tr>
    <td>Email:</td>
    <td><input type="email" name="email" id="email" placeholder="harry.potter@xyz.com" required="required" /></td>
  </tr>
  <tr>
    <td>Password:</td>
    <td><input type="password" name="password" id="password" required="required" /></td>
  </tr>
  <tr>
    <td>Profile Picture:</td>
    <td><input type="file" name="profilePic" id="profilePic" /></td>
  </tr>
  <tr>
      <td><input type="submit" name="submit" class="button" id="submit" value="Submit" />      
          <input type="reset" name="reset" class="button" id="reset" value="Reset" /></td>
    <td>
    <?php
                        if($error==1)
                        {
                            echo '
                                
                                <div class=\'error\'>
                                User Creation Failed!
                                </div>
                            ';
                        }
                        if($error==2)
                        {
                            echo '
                                
                                <div class=\'error\'>
                                Your image must not exceed 1MB!
                                </div>
                            ';
                        }
                        if($error==3)
                        {
                            echo '
                                
                                <div class=\'error\'>
                                Only images in JPG are acceptable!
                                </div>
                            ';
                        }
                        ?>
    </td>
  </tr>
</table>
</form>
</div>

        <?php
        include 'footer.php';
        ?>
    </body>
</html>
