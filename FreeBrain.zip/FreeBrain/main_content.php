<?php
require 'Controller/MainContentGenerator.php';

$service = new Service();
$serviceDAO = new ServiceDAO();

$servicesByArt = $serviceDAO->getServicesByCategory('Art');
$servicesByMusic = $serviceDAO->getServicesByCategory('Music');
$servicesByDance = $serviceDAO->getServicesByCategory('Dance');
$servicesByTheatre = $serviceDAO->getServicesByCategory('Theatre');
$servicesByOther = $serviceDAO->getServicesByCategory('Other');

?>

<h1>Art</h1>
<table width="100%" class="table" id='left_align'>
  <tr>
    <th scope="col">Title</th>
    <th scope="col">Name</th>
    <th scope="col">Type</th>
    <th scope="col">Specialization</th>
    <th scope="col">Description</th>
    <th scope="col">Image</th>
    <th scope="col">Video</th>
    <th scope="col">Price</th>
  </tr>   
            <?php
            for($i=0;$i<=count($servicesByArt);$i++)
            {
                $user=array_pop($servicesByArt);
                $service=  array_pop($servicesByArt);
                echo '<tr>';
                echo '<td>'. $service->title.'</td>';
                echo '<td><a href="Controller/Profile.php?id='.$user->id.'">'. $user->fname.' '.$user->lname.'</a></td>';
                echo '<td>'. $service->type.'</td>';
                echo '<td>'. $service->special.'</td>';
                echo '<td>'. $service->desc.'</td>';
                echo '<td>';               
                echo '<a class="fancybox" href="'.$service->image.'"><img src="images/Image.png"  width="32" height="32"/></a>';
                echo '</td>';
                echo '<td>';
                echo '<a class="fancybox-media" href="'.$service->video.'"><img src="images/Video.png"  width="32" height="32"/></a>';                
                echo '</td>';
                echo '<td>'. $service->price.'</td>';
                
                
                echo '</tr>';
              
            }
            
            ?>
</table>
<hr/>
<h1>Dance</h1>

<table width="100%" class="table" id='left_align'>
  <tr>
    <th scope="col">Title</th>
    <th scope="col">Name</th>
    <th scope="col">Type</th>
    <th scope="col">Specialization</th>
    <th scope="col">Description</th>
    <th scope="col">Image</th>
    <th scope="col">Video</th>
    <th scope="col">Price</th>
  </tr>   
            <?php
            for($i=0;$i<=count($servicesByDance);$i++)
            {
                $user=array_pop($servicesByDance);
                $service=  array_pop($servicesByDance);
                echo '<tr>';
                echo '<td>'. $service->title.'</td>';
                echo '<td><a href="Controller/Profile.php?id='.$user->id.'">'. $user->fname.' '.$user->lname.'</a></td>';
                echo '<td>'. $service->type.'</td>';
                echo '<td>'. $service->special.'</td>';
                echo '<td>'. $service->desc.'</td>';
               echo '<td>';               
                echo '<a class="fancybox" href="'.$service->image.'"><img src="images/Image.png"  width="32" height="32"/></a>';
                echo '</td>';
                echo '<td>';
                echo '<a class="fancybox-media" href="'.$service->video.'"><img src="images/Video.png"  width="32" height="32"/></a>';                
                echo '</td>';
                echo '<td>'. $service->price.'</td>';
                
                
                echo '</tr>';
              
            }
            
            ?>
</table>
<hr/>
<h1>Music</h1>
<table width="100%" class="table" id='left_align'>
  <tr>
    <th scope="col">Title</th>
    <th scope="col">Name</th>
    <th scope="col">Type</th>
    <th scope="col">Specialization</th>
    <th scope="col">Description</th>
    <th scope="col">Image</th>
    <th scope="col">Video</th>
    <th scope="col">Price</th>
  </tr>   
            <?php
            for($i=0;$i<=count($servicesByMusic);$i++)
            {
                $user=array_pop($servicesByMusic);
                $service=  array_pop($servicesByMusic);
                echo '<tr>';
                echo '<td>'. $service->title.'</td>';
                echo '<td><a href="Controller/Profile.php?id='.$user->id.'">'. $user->fname.' '.$user->lname.'</a></td>';
                echo '<td>'. $service->type.'</td>';
                echo '<td>'. $service->special.'</td>';
                echo '<td>'. $service->desc.'</td>';
                echo '<td>';               
                echo '<a class="fancybox" href="'.$service->image.'"><img src="images/Image.png"  width="32" height="32"/></a>';
                echo '</td>';
                echo '<td>';
                echo '<a class="fancybox-media" href="'.$service->video.'"><img src="images/Video.png"  width="32" height="32"/></a>';                
                echo '</td>';
                echo '<td>'. $service->price.'</td>';
                
                
                echo '</tr>';
              
            }
            
            ?>
</table>
<hr/>
<h1>Theatre</h1>
<table width="100%" class="table" id='left_align'>
  <tr>
    <th scope="col">Title</th>
    <th scope="col">Name</th>
    <th scope="col">Type</th>
    <th scope="col">Specialization</th>
    <th scope="col">Description</th>
    <th scope="col">Image</th>
    <th scope="col">Video</th>
    <th scope="col">Price</th>
  </tr>   
            <?php
            for($i=0;$i<=count($servicesByTheatre);$i++)
            {
                $user=array_pop($servicesByTheatre);
                $service=  array_pop($servicesByTheatre);
                echo '<tr>';
                echo '<td>'. $service->title.'</td>';
                echo '<td><a href="Controller/Profile.php?id='.$user->id.'">'. $user->fname.' '.$user->lname.'</a></td>';
                echo '<td>'. $service->type.'</td>';
                echo '<td>'. $service->special.'</td>';
                echo '<td>'. $service->desc.'</td>';
                echo '<td>';               
                echo '<a class="fancybox" href="'.$service->image.'"><img src="images/Image.png"  width="32" height="32"/></a>';
                echo '</td>';
                echo '<td>';
                echo '<a class="fancybox-media" href="'.$service->video.'"><img src="images/Video.png"  width="32" height="32"/></a>';                
                echo '</td>';
                echo '<td>'. $service->price.'</td>';
                
                
                echo '</tr>';
              
            }
            
            ?>
</table>
<hr/>
<h1>Other</h1>
<table width="100%" class="table" id='left_align'>
  <tr>
    <th scope="col">Title</th>
    <th scope="col">Name</th>
    <th scope="col">Type</th>
    <th scope="col">Specialization</th>
    <th scope="col">Description</th>
    <th scope="col">Image</th>
    <th scope="col">Video</th>
    <th scope="col">Price</th>
  </tr>   
            <?php
            for($i=0;$i<=count($servicesByOther);$i++)
            {
                $user=array_pop($servicesByOther);
                $service=  array_pop($servicesByOther);
                echo '<tr>';
                echo '<td>'. $service->title.'</td>';
                echo '<td><a href="Controller/Profile.php?id='.$user->id.'">'. $user->fname.' '.$user->lname.'</a></td>';
                echo '<td>'. $service->type.'</td>';
                echo '<td>'. $service->special.'</td>';
                echo '<td>'. $service->desc.'</td>';
                echo '<td>';               
                echo '<a class="fancybox" href="'.$service->image.'"><img src="images/Image.png"  width="32" height="32"/></a>';
                echo '</td>';
                echo '<td>';
                echo '<a class="fancybox-media" href="'.$service->video.'"><img src="images/Video.png"  width="32" height="32"/></a>';                
                echo '</td>';
                echo '<td>'. $service->price.'</td>';
                
                
                echo '</tr>';
              
            }
            
            ?>
</table>