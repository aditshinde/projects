<header>
    <table>
        <tr>
            <td>
                <img src="images/logo.gif" height="40" width="40" alt="Logo"/>
            </td>
            <td>
                <h1>
                TheFreeBird.com
                </h1>
            </td>
        </tr>
    </table>    
</header>