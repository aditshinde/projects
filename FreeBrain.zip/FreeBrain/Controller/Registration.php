<?php
require '../Model/UserDAO.php';

$fname= filter_var($_POST['fname'], \FILTER_SANITIZE_STRING);
$lname=\filter_var($_POST['lname'], \FILTER_SANITIZE_STRING);
$dob=\filter_var($_POST['dob'], \FILTER_SANITIZE_STRING);
$location=\filter_var($_POST['location'], \FILTER_SANITIZE_STRING);
$mobile=\filter_var($_POST['mobile'], \FILTER_SANITIZE_STRING);
$email=\filter_var($_POST['email'], \FILTER_SANITIZE_STRING);
$pass=\filter_var($_POST['password'], \FILTER_SANITIZE_STRING);
if(isset($_FILES['profilePic']['name']))
{
    $image=$_FILES['profilePic']['name'];
    $size=$_FILES['profilePic']['size'];
    $type=$_FILES['profilePic']['type'];
    $tmp=$_FILES['profilePic']['tmp_name'];
    
    //File size and extension 
$max = 1048576; 
$extension = strtolower(substr($image, strpos ($image, '.') +1)); 

//Upload codes 
if ($size > $max) 
                { 
        header('Location: ../register.php?error=2');
           
            } 
    elseif ($extension !== 'jpg') 
                { 
        header('Location: ../register.php?error=3');
            
            } 
            else 
            { 
                
            $loc = '../upload/'; 
            move_uploaded_file($tmp, $loc.$image); 
            
            } 
} 

$userDAO = new UserDAO();
$result=$userDAO->addUser(md5($email),$fname, $lname, $dob, $location, $mobile, $email, $pass, $image);

if ($result == true) 
    {
    header('Location: ../login.php');
    } 
else
{
    header('Location: ../register.php?error=1');
}
