<?php
session_start();
require '../Model/UserDAO.php';

$email=\filter_var($_POST['email'], \FILTER_SANITIZE_STRING);
$pass=\filter_var($_POST['pass'], \FILTER_SANITIZE_STRING);

$userDAO = new UserDAO();
$result=$userDAO->validateLogin($email, $pass);

if ($result != false) 
    {
            $_SESSION['id']=  session_id();
            $_SESSION['fname']=$result->fname;
            $_SESSION['lname']=$result->lname;
            $_SESSION['dob']=$result->dob;
            $_SESSION['location']=$result->location;
            $_SESSION['mobile']=$result->mobile;
            $_SESSION['email']=$result->email;
            $_SESSION['profilePic']=$result->profilePic;
    header('Location: ../home.php');
    } 
else
{
    header('Location: ../login.php?error=1');
}