<?php
require 'Model/ServiceDAO.php';

$serviceDAO = new ServiceDAO();

$servicesByArt = $serviceDAO->getServicesByCategory('Art');
$servicesByMusic = $serviceDAO->getServicesByCategory('Music');
$servicesByDance = $serviceDAO->getServicesByCategory('Dance');
$servicesByTheatre = $serviceDAO->getServicesByCategory('Theatre');
$servicesByOther = $serviceDAO->getServicesByCategory('Other');