<?php
$name=filter_var($_POST['name'], \FILTER_SANITIZE_STRING);
$email=filter_var($_POST['email'], \FILTER_SANITIZE_STRING);
$to="aditdineshshinde@gmail.com";
$subject="FreeBird Comment by ".$name;
$message=filter_var($_POST['message'], \FILTER_SANITIZE_STRING).""
        . "\nSender:".$name."\nEmail:".$email;

if(mail($to, $subject, $message))
{
    header("Location: ../contact_us.php?error=0");
}
else
{
    header("Location: ../contact_us.php?error=1");
}