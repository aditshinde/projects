<?php
session_start();
require '../Model/UserDAO.php';

$profile = array();
$user= new User();
$userDAO=new UserDAO();

if(isset($_GET['id']))
{
    $id = $_GET['id'];
    $user = $userDAO->getUser($id);
    
    array_push($profile, $user->profilePic);
    array_push($profile, $user->email);
    array_push($profile, $user->mobile);
    array_push($profile, $user->location);
    array_push($profile, $user->dob);
    array_push($profile, $user->lname);
    array_push($profile, $user->fname);
    array_push($profile, $user->id);
    
    if($user!=false)
    {
        $_SESSION['profile']=$profile;
        
        header('Location: ../profile.php');
    }
    else
    {
        header('Location: ../profile.php');
    }
}
else
{
        header('Location: ../profile.php');
}