<?php
session_start();
require '../Model/ServiceDAO.php';

$email=$_SESSION['email'];
$serviceDAO=new ServiceDAO();
$result=$serviceDAO->getMyServices(md5($email));

if($result!=false)
{
    $_SESSION['service']=$result;
    header('Location: ../my_services.php');
}
else
{
    header('Location: ../home.php');
}



