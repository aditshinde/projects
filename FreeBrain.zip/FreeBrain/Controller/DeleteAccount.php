<?php
session_start();
require '../Model/UserDAO.php';
$email=$_SESSION['email'];

$userDAO=new UserDAO();
$result=$userDAO->deleteUser(md5($email));

if($result!=false)
{
    header('Location: Logout.php');
}
else
{
    header('Location: ../home.php');
}