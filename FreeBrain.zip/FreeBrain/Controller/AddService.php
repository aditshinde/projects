<?php
session_start();
require '../Model/ServiceDAO.php';

$title= filter_var($_POST['title'], \FILTER_SANITIZE_STRING);
$type=\filter_var($_POST['type'], \FILTER_SANITIZE_STRING);
$categ=\filter_var($_POST['categ'], \FILTER_SANITIZE_STRING);
$special=\filter_var($_POST['special'], \FILTER_SANITIZE_STRING);
$desc=\filter_var($_POST['desc'], \FILTER_SANITIZE_STRING);
$email=$_SESSION['email'];
$image=\filter_var($_POST['upload_image'], \FILTER_SANITIZE_STRING);
$video=\filter_var($_POST['upload_video'], \FILTER_SANITIZE_STRING);
$price=\filter_var($_POST['price'], \FILTER_SANITIZE_STRING);

//if(isset($_FILES['upload_image']['name']))
//{
//    $image=$_FILES['upload_image']['name'];
//    $size=$_FILES['upload_image']['size'];
//    $typ=$_FILES['upload_image']['type'];
//    $tmp=$_FILES['upload_image']['tmp_name'];
//    
//    //File size and extension 
//    $max = 1048576; 
//    $extension = strtolower(substr($image, strpos ($image, '.') +1)); 
//
//    //Upload codes 
//    if ($size > $max) 
//                { 
//        header('Location: ../add_service.php?error=2');
//           
//            } 
//    elseif ($extension !== 'jpg') 
//                { 
//        header('Location: ../add_service.php?error=3');
//            
//            } 
//            else 
//            { 
//                
//            $loc = '../upload/'; 
//            move_uploaded_file($tmp, $loc.$image); 
//            
//            } 
//}
//if(isset($_FILES['upload_video']['name']))
//{
//    $video=$_FILES['upload_video']['name'];
//    $size=$_FILES['upload_video']['size'];
//    $typ=$_FILES['upload_video']['type'];
//    $tmp=$_FILES['upload_video']['tmp_name'];
//    
//    //File size and extension 
//    $max = 10485760; 
//    $extension = strtolower(substr($video, strpos ($video, '.') +1)); 
//
//    //Upload codes 
//    if ($size > $max) 
//                { 
//        header('Location: ../add_service.php?error=4');
//           
//            } 
//    elseif ($extension !== 'mp4' || $extension !== 'avi' || $extension !== 'flv') 
//                { 
//        header('Location: ../add_service.php?error=5');
//            
//            } 
//            else 
//            { 
//                
//            $loc = '../upload/'; 
//            move_uploaded_file($tmp, $loc.$video); 
//            
//            } 
//}

$serviceDAO = new ServiceDAO();
$result=$serviceDAO->addService($title, $type, $categ, $special, $desc, md5($email), $image, $video, $price);

if($result==true)
{
    header('Location: ../add_service.php?error=0');
}
else 
{
    header('Location: ../add_service.php?error=1');
    
}
