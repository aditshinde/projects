<?php
session_start();
require '../Model/ServiceDAO.php';
$sid=filter_var($_GET['sid'], \FILTER_SANITIZE_STRING);

$serviceDAO=new ServiceDAO();
$result=$serviceDAO->deleteService($sid);
$email=$_SESSION['email'];
$result=$serviceDAO->getMyServices(md5($email));

if($result!=false)
{
    $_SESSION['service']=$result;
    header('Location: ../my_services.php?error=0');
}
elseif($result==NULL)
{
    header('Location: ../home.php');
}
else
{
    header('Location: ../my_services.php?error=1');
}