<?php
require 'User.php';
require 'Service.php';
require 'Database.php';

class ServiceDAO extends Database
{
    public function addService($title, $type, $categ, $special, $desc, $id, $image, $video, $price)
    {
        $db = new Database();
        $con=$db->connectDB();
        
        $stmt=$con->prepare("INSERT INTO `SERVICES`(`title`, `type`, `category`"
                . ", `special`, `description`, `id`, `image`, `video`, `price`) "
                . "VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("sssssssss", $title, $type, $categ, $special, $desc, $id, $image, $video, $price);
        
        
        if($stmt->execute() === TRUE)
        {
            $stmt->close();
           
            $db->disconnectDB();
            return true;
        }
        else
        {
            $stmt->close();
            
            $db->disconnectDB();
            return false;
        }
        
    }
    
    public function getMyServices($id) 
    {
        $title= $type= $categ= $special= $desc= $image= $video= $price='';
        $flag=false;
        $serviceArray = array();
        $db = new Database();
        $con = $db->connectDB();
        $stmt = $con->prepare("SELECT SID, TITLE,TYPE,CATEGORY,SPECIAL,"
                . "DESCRIPTION,IMAGE,VIDEO,PRICE FROM SERVICES WHERE ID = ? ");
        $stmt->bind_param("s",$id);
        if($stmt->execute()==true)
        {
            $flag=true;
        }
        $stmt->bind_result($sid,$title, $type, $categ, $special, $desc, $image, $video, $price);
        while($stmt->fetch())
        {
            $service = new Service();
            $service->sid=$sid;
            $service->title=$title;
            $service->type=$type;
            $service->category=$categ;
            $service->special=$special;
            $service->desc=$desc;
            $service->image=$image;
            $service->video=$video;
            $service->price=$price; 
            
            array_push($serviceArray, $service);
        }
        $stmt->close();
        
        $db->disconnectDB();
        
        if ($flag==true)
        {
                   
           
            return $serviceArray;
        }
        else
        {
            return false;
        }
        
    }
    
    public function getServicesByCategory($categ) 
    {
        $title= $type= $special= $desc= $image= $video=
                $freelancerId=$serviceId=$fname=$lname=$price='';
        $flag=false;
        $serviceArray = array();
        $db = new Database();
        
        $con = $db->connectDB();
        
        $stmt = $con->prepare("SELECT TITLE, TYPE, SPECIAL, "
                . " DESCRIPTION, IMAGE, VIDEO, PRICE ,"
                . " FREELANCERS.ID,SERVICES.ID, FNAME, LNAME "
                . " FROM SERVICES,FREELANCERS WHERE FREELANCERS.ID=SERVICES.ID"
                . " AND CATEGORY=?");
        $stmt->bind_param("s",$categ);
        if($stmt->execute()==true)
        {
            $flag=true;
        }
        $stmt->bind_result($title, $type, $special, $desc, $image, $video, 
                $price,$freelancerId,$serviceId,$fname,$lname);
        while($stmt->fetch())
        {
            $service = new Service();
            $service->title=$title;
            $service->type=$type;
            $service->category=$categ;
            $service->special=$special;
            $service->desc=$desc;
            $service->image=$image;
            $service->video=$video;
            $service->price=$price;
            $user = new User();
            $user->id=$freelancerId;
            $user->fname=$fname;
            $user->lname=$lname;
            
            array_push($serviceArray, $service);
            array_push($serviceArray, $user);
        }
        $stmt->close();
        
        $db->disconnectDB();
        
        if ($flag==true)
        {       
           
            return $serviceArray;
        }
        else
        {
            return false;
        }
        
    }
    
    public function deleteService($sid)
    {
        $db = new Database();
        $con=$db->connectDB();
        
        $stmt=$con->prepare("DELETE FROM SERVICES WHERE SID=?");
        $stmt->bind_param("i",  intval($sid));       
        
        if($stmt->execute() === TRUE)
        {
            $stmt->close();
            
            $db->disconnectDB();
            return true;
        }
        else
        {
            $stmt->close();
            
            $db->disconnectDB();
            return false;
        }
        
    }
    
}
