<?php
class User 
{
   var $id;
   var $fname;
   var $lname;
   var $dob;
   var $location;
   var $mobile;
   var $email;
   var $password;
   var $profilePic;
}
