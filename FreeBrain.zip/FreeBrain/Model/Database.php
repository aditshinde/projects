<?php

class Database extends mysqli
{
    var $host;
    var $port;
    var $socket;
    var $user;
    var $password;
    var $dbname;
    var $con;

    public function connectDB()
    {
        $this->host="localhost";
        $this->user="root";
        $this->password="";
        $this->dbname="test";
        $this->port=3306;
        $this->socket="";

        $this->con = new mysqli($this->host, $this->user, $this->password, 
                $this->dbname, $this->port, $this->socket) 
                or die ('Could not connect to the database server' . mysqli_connect_error());
        
        
        
        return $this->con;
    }
    
    public function disconnectDB()
    {
        $this->con->close();
    }
}
