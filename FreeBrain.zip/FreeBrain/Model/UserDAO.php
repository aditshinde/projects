<?php
require 'User.php';
require 'Database.php';
function __autoload($class_name) {
    include $class_name . '.php';
}



class UserDAO extends Database
{    
    public function addUser($id,$fname, $lname, $dob, $location, $mobile, $email, $pass , $image)
    {
        $db = new Database();
        $con=$db->connectDB();
        
        $stmt=$con->prepare("INSERT INTO FREELANCERS VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("sssssssss",$id, $fname, $lname, $dob, $location, $mobile, $email, $pass, $image);
        
        
        if($stmt->execute() === TRUE)
        {
            $stmt->close();
            
            $db->disconnectDB();
            return true;
        }
        else
        {
            $stmt->close();
            
            $db->disconnectDB();
            return false;
        }
        
    }
    
    public function validateLogin($email,$pass) 
    {
        $fname=$lname= $dob= $location= $mobile= $resultEmail=$profilePic='';
        $db = new Database();
        $con = $db->connectDB();
        $stmt = $con->prepare("SELECT FNAME,LNAME,DOB,LOCATION,MOBILE,EMAIL,PROFILEPIC "
                . "FROM FREELANCERS WHERE EMAIL = ? AND PASSWORD = ?");
        $stmt->bind_param("ss",$email,$pass);
        $stmt->execute();
        $stmt->bind_result($fname, $lname, $dob, $location, $mobile, $resultEmail, $profilePic);
        $stmt->fetch();
        $stmt->close();
        
        $db->disconnectDB();
        
        if (strcasecmp($resultEmail,$email)== 0)
        {
            $user = new User();
            $user->fname=$fname;
            $user->lname=$lname;
            $user->dob=$dob;
            $user->location=$location;
            $user->mobile=$mobile;
            $user->email=$email;
            $user->profilePic=$profilePic;
           
            return $user;
        }
        else
        {
            return false;
        }
        
    }

    public function deleteUser($id)
    {
        $db = new Database();
        $con=$db->connectDB();
        
        $stmt=$con->prepare("DELETE FROM FREELANCERS,SERVICES WHERE ID=?");
        $stmt->bind_param("s",$id);       
        
        if($stmt->execute() === TRUE)
        {
            $stmt->close();
            
            $db->disconnectDB();
            return true;
        }
        else
        {
            $stmt->close();
            
            $db->disconnectDB();
            return false;
        }
        
    }
    
    public function getUser($id)
    {
        $db = new Database();
        $con=$db->connectDB();
        $fname=$lname= $dob= $location= $mobile= $email=$profilePic='';
        $stmt=$con->prepare("SELECT FNAME,LNAME,DOB,LOCATION,MOBILE,EMAIL,PROFILEPIC "
                . "FROM FREELANCERS WHERE ID =?");
        $stmt->bind_param("s",$id);      
                      
        if ($stmt->execute()==true)
        {
            $stmt->bind_result($fname, $lname, $dob, $location, $mobile, $email, $profilePic);
            $stmt->fetch();
            $user = new User();
            $user->fname=$fname;
            $user->lname=$lname;
            $user->dob=$dob;
            $user->location=$location;
            $user->mobile=$mobile;
            $user->email=$email;
            $user->profilePic=$profilePic;
           
            return $user;
        }
        else
        {
            return false;
        }
        $stmt->close();       
        $db->disconnectDB();
    }
    
    
}
