<footer>
    <hr/>
    <div class="social_icons">
        <a href="https://www.facebook.com" target="_blank">
            <img src="images/Facebook.png" width="32" height="32" alt="Facebook"/>
        </a>
        <a href="https://www.plus.google.com" target="_blank">
            <img src="images/Google.png" width="32" height="32" alt="Google+"/>
        </a>
        <a href="https://www.twitter.com" target="_blank">
            <img src="images/Twitter.png" width="32" height="32" alt="Twitter"/>
        </a>
    </div>
    
<?php
echo "Copyright &copy; 2013-" .date("Y")." TE-C3";
?>
</footer>