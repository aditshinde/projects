<?php
session_start();

$fname=$lname= $dob= $location= $mobile= $email=$profilePic=$id=null;
        
if(isset($_SESSION['id']))
{
    $id = $_SESSION['id'];
    $fname=$_SESSION['fname'];
    $lname=$_SESSION['lname'];
    $dob=$_SESSION['dob'];
    $location=$_SESSION['location'];
    $mobile=$_SESSION['mobile'];
    $email=$_SESSION['email'];
    $profilePic=$_SESSION['profilePic'];
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link href="View/style.css" rel="stylesheet" type="text/css"/>
        <title>TheFreeBird-Home</title>
        <?php
        include 'fancybox.html';
        ?>
    </head>
    <body>
        <?php
        include 'header.php';       
        include 'user_menu.php';
        
        ?>
        <div class="content">
            <?php 
        include 'main_content.php';
        ?>
</div>
        
        
        
        
        <?php 
        include 'footer.php';
        ?>
    </body>
</html>
