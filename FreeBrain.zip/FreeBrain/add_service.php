<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>TheFreeBird-Add Service</title>
        <link href="View/style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
        include 'header.php';
        include 'user_menu.php';
        $error=-1;
        ?>
        
        <div class="content">
  <h1>Add Service</h1><br />
  <form action="Controller/AddService.php" method="post" enctype="multipart/form-data" name="add_service" id="add_service">
    <table width="100%" border="0">
      <tr>
          <td width="30%">
             Title: 
          </td>
          <td width="70%">
              <input type="text" name="title" placeholder="Guitar lessons" required="true" />
          </td>
      </tr>
      <tr>
          <td>
             Type: 
          </td>
          <td>
              <select  name="type" id="type"  required="true" >
                <option value="Online">Online</option>
                <option value="Offline">Offline</option>
                <option value="Both">Both</option>
                <option value="Other">Other</option>
        </select>
          </td>
      </tr>
      <tr>
        <td >Category :</td>
        <td >
            <select  name="categ" id="categ">
                <option value="Art">Art</option>
                <option value="Music">Music</option>
                <option value="Dance">Dance</option>
                <option value="Theatre">Theatre</option>
                <option value="Other">Other</option>
            </select>
        </td>
      </tr>
      
      <tr>
        <td>Specialization :</td>
        <td>
            <input type="text" name="special" placeholder="Guitar Chords" required="true"/>
        </td>
      </tr>
      <tr>
        <td>Description (1000 words max.) :</td>
        <td><textarea name="desc" id="desc" cols="45" rows="5" 
                      placeholder="Brief description about the service you can provide the world..." 
                      required="true"></textarea></td>
      </tr>
      <tr>
        <td>Image (Optional) :</td>
        <td><input type="url" name="upload_image" placeholder="URL" id="upload_image" /></td>
      </tr>
      <tr>
        <td>Video (Optional) :</td>
        <td><input  type="url" name="upload_video" placeholder="URL" id="upload_video" /></td>
      </tr>
      <tr>
        <td>Price :</td>
        <td><input  type="number" name="price" id="price" value="0" min="0" max="9999999999"/></td>
      </tr>
      <tr>
          <td><input class="button" type="submit" name="submit" id="submit" value="Add" /></td>
          <td>
              <?php
                        if($error==0)
                        {
                            echo '
                                
                                <div class=\'success\'>
                                Service Addition Successful!
                                </div>
                            ';
                        }
                        if($error==1)
                        {
                            echo '
                                
                                <div class=\'error\'>
                                Service Addition Failed!
                                </div>
                            ';
                        }
                        if($error==2)
                        {
                            echo '
                                
                                <div class=\'error\'>
                                Your image must not exceed 1MB!
                                </div>
                            ';
                        }
                        if($error==3)
                        {
                            echo '
                                
                                <div class=\'error\'>
                                Only images in JPG are acceptable!
                                </div>
                            ';
                        }
                        if($error==4)
                        {
                            echo '
                                
                                <div class=\'error\'>
                                Your video must not exceed 10MB!
                                </div>
                            ';
                        }
                        if($error==5)
                        {
                            echo '
                                
                                <div class=\'error\'>
                                Only video in MP4,AVI,FLV are acceptable!
                                </div>
                            ';
                        }
                        ?>
          </td>
        
      </tr>
      
    </table>
  </form>
  

</div>
        
        
        <?php 
        include 'footer.php';
        ?>
    </body>
</html>
