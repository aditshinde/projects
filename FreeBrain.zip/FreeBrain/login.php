<!DOCTYPE html>
<?php
if(session_status()==2)session_destroy();
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>TheFreeBird-Login</title>
        <link href="View/style.css" rel="stylesheet" type="text/css"/>
        
    </head>
    <body>
       <?php
        include 'header.php';
        include 'main_menu.php';
        $error=0;
        if(isset($_GET['error']))
                {
                    $error=$_GET['error'];
                }       
        ?>
        <div class="content">
            
                <h2>Login</h2>
                <form action="Controller/LoginCheck.php" method="post">
                    <table>
                        <?php
                        if($error==1)
                        {
                            echo '
                                <tr>
                            <td></td>    
                            <td>
                                <div class=\'error\'>
                                Incorrect Email/Password!
                                </div>
                            </td>
                            </tr>';
                        }
                        ?>
                        <tr>
                            <td>
                                Email Id:
                            </td>
                            <td>
                                <input type="email" name="email" required />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Password:
                            </td>
                            <td>
                                <input type="password" name="pass" required />
                            </td>
                        </tr>
                        
                        <tr>
                            <td>
                                <input class="button" type="reset" value="Reset" />
                            </td>
                            <td>
                                <input class="button" type="submit" value="Login" />
                            </td>
                        </tr>
                        
                    </table>

                </form>
                
                
            

        </div>
       
        <?php
        include 'footer.php';
        ?>
    </body>
</html>
