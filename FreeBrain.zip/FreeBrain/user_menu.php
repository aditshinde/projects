<nav>
    <ul>
        <li><a href="home.php">Home</a></li> 
        <li><a href="profile.php?self=1">Profile</a></li>
        <li><a href="add_service.php">Add Services</a></li>
        <li><a href="Controller/MyServices.php">My Services</a></li>
        <li><a href="Controller/DeleteAccount.php">Delete Account</a></li>
        <li><a href="Controller/Logout.php">Logout</a></li>        
    </ul>
</nav>
