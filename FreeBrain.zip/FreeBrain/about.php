<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>TheFreeBird-About</title>
        <link href="View/style.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery-1.11.3.js" type="text/javascript"></script>
        <?php
//        include 'fancybox.html';
//        ?>
    </head>
    <body>
        <?php
        include 'header.php';
        ?>
        <?php
        include 'main_menu.php';
        ?>
        <div class="content">
        <?php
        include 'gallery.php';
        ?>
            <h1>
                About FreeBird
            </h1>
            <article>
            <p>
                The website is all about sharing talent for the people who want to learn something new. The website, 

freebrain.com provides the user a platform to share their talent with the world and also learn something new 

free of cost. The website consist of different pages includinh the registration, sign up, contact us and about 

us page. It helps the user to provide their details so that they can be approachable by as many people as 

possible.
            </p>
            <p>
                The teachers are supposed to give their contact details such as mobile number and a email address

so that the interested users can approach them. We have analyzed many similar website and we have come 

up to a solution that making the sharing of talent free of cost will attract many people. We  make it possible 

for the learner to view the profile of the teacher and see their demo which will be provided by the teacher.
            </p>
            
            <p>
                Initially we have made the website non dynamic, I.e, noone can leave a comment below on the profile but 

we plan to bring this possibility up in the future. Also, this website can be very fruitful for the students point 

of view since they can share and learn anything they want from this website the main aim of making 

this website was to keep the front end or the user interface as simple and as approachable as 

possible.
            </p>
            <p>
                For now, the talents which can be shared include dancing singing painting etc. The

talents to be shared can be offline or online depending on the choice of the teacher. Also we 

have tried making it easy for the user to search for a particular person or talent by our user 

friendly interface.
            </p>
            </article>            
        </div>        
        <?php
        include 'footer.php';
        ?>
    </body>
</html>
