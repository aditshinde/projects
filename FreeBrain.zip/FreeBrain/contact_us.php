<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>TheFreeBird-Contact Us</title>
        <link href="View/style.css" rel="stylesheet" type="text/css"/>
        
        <script>
            
function initialize() {
  var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 15,
    center: {lat: 19.0330, lng: 73.0200}
  });
  var geocoder = new google.maps.Geocoder();

  
  geocodeAddress(geocoder, map);
}

function geocodeAddress(geocoder, resultsMap) {
  var address ="Ramrao Adik Institute of Technology";
  geocoder.geocode({'address': address}, function(results, status) {
    if (status === google.maps.GeocoderStatus.OK) {
      resultsMap.setCenter(results[0].geometry.location);
      var marker = new google.maps.Marker({
        map: resultsMap,
        position: results[0].geometry.location
      });
    } else {
      alert('Geocode was not successful for the following reason: ' + status);
    }
     google.maps.event.addListener(marker, 'click', function() {
        infoWindow.setContent(html);
        infoWindow.open(map, marker);
      });
  });
}
function loadScript()
{
  var script = document.createElement("script");
  script.type = "text/javascript";
  script.src = "http://maps.googleapis.com/maps/api/js?key=&sensor=false&callback=initialize";
  document.body.appendChild(script);
}

window.onload = loadScript;
</script>
    </head>
    <body>
        <?php
        include 'header.php';
        ?>
        <?php
        include 'main_menu.php';
        ?>
        <div class="content">
       
            <h1>
                Contact Us
            </h1>
            <p>
                We would love to hear you out. Kindly email us your comments,
                queries or suggestions on the email address provided below. 
            </p>
            <p>
                Ring us on 1800-9999-8989
            </p>        
            <p>
                Email us at
                <a href="mailto:freebird@gmail.com" 
                   target="_new">freebird@gmail.com</a> 
            </p>
        </form>
        <div id="map" style="width:1000px;height:500px;"></div>
        </div>        
        <?php
        include 'footer.php';
        ?>
    </body>
</html>
