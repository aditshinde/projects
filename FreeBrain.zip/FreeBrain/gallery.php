<div class="gallery">
    <img id="img1" src='images/gallery/1.jpg'/>
    <img id="img2" hidden="true" src='images/gallery/2.jpg'/>
    <img id="img3" hidden="true" src='images/gallery/3.jpg'/>
</div>

<script>
    $(document).ready(function (){
        function img1()
        {
            $("#img1").fadeIn(1000).delay(5000).fadeOut(1000,img2);
        }
        function img2()
        {
            $("#img2").fadeIn(1000).delay(5000).fadeOut(1000,img3);
        }
        function img3()
        {
            $("#img3").fadeIn(1000).delay(5000).fadeOut(1000,img1);
        }
    img1();    
    });
</script>