/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;

import Model.BookDeleteFormBean;
import Model.BookServices;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
 *
 * @author Adit Shinde
 */
public class BookDeleteTitleAction extends Action
{
    @Override
    public ActionForward execute(ActionMapping mapping,ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
    {
        
        ActionErrors errors = new ActionErrors();
        saveErrors(request,errors);
       boolean DeleteBook=true;
        
        try
       {
        
        
        BookDeleteFormBean bForm = (BookDeleteFormBean) form;
        BookServices bs = new BookServices();
        
        DeleteBook = bs.DeleteBook(bForm.getTitle());
        request.setAttribute("book", bForm);
               
        
        
       }
       catch(RuntimeException e)
       {
           e.printStackTrace(System.err);
           
           errors.add(ActionErrors.GLOBAL_MESSAGE,new ActionMessage("errors.general",e.getMessage()));
           mapping.findForward("error");
       }
       if(DeleteBook==true)
        {
            return mapping.findForward("success");
        }
        else
        {
            return mapping.findForward("error");
        }
    }
}
