/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
 *
 * @author Adit Shinde
 */
public class BookSearchFormBean extends ActionForm
{
    private String isbn;
    private String title;
    

    /**
     * @return the isbn
     */
    public String getIsbn() {
        return isbn;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

   

    /**
     * @param isbn the isbn to set
     */
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    
    
    @Override
    public ActionErrors validate(ActionMapping mapping,HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
        
        try
        {
        if(isbn.equals("") && title.equals(""))
        {
            errors.add("delete",new ActionMessage("errors.delete"));
        }
        }
        catch(NullPointerException e)
        {
            errors.add("delete",new ActionMessage("errors.delete"));
        }
        
        return errors;
    }
    
    
}
