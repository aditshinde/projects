/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author Adit Shinde
 */
public class LoginData 
{
    private String type;
    private String user;
    private String pass;

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * @return the pass
     */
    public String getPass() {
        return pass;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @param user the user to set
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * @param pass the pass to set
     */
    public void setPass(String pass) {
        this.pass = pass;
    }

    public LoginData() 
    {
    }

    public LoginData(String type, String user, String pass) {
        this.type = type;
        this.user = user;
        this.pass = pass;
    }
    
    
    
}
