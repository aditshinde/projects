/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Adit Shinde
 */
public class BookServices 
{
    boolean b;
    List list = new LinkedList();
    BookDAO bdao = new BookDAO();
    
    public boolean CreateNewBook(String isbn,String title,String author,String pub,String dop,
            String price,String discnt)
    {
        b = bdao.CreateNewBook(isbn,title,author,pub,dop,price,discnt);
        return b;
    }
    
    public boolean DeleteBook(String str)
    {
        b = bdao.DeleteBook(str);
        return b;
    }
    
    public List ViewAll()
    {
        try 
        {
            list = bdao.ViewAll();
        } catch (SQLException ex) 
        {
            list.add("Error in BookSevices:ViewAll"+ex.getMessage());
        }
        return list;
    }
    
    public List ViewBookIsbn(String isbn)
    {
        try 
        {
            list = bdao.ViewBookIsbn(isbn);
        } 
        catch (SQLException ex) 
        {
            list.add("Error in BookSevices:ViewBookIsbn"+ex.getMessage());
        }
        if(list.isEmpty())
        {
        list.add("No Book Found!");
        }
        return list;
        
    }
    
    public List ViewBookTitle(String title)
    {
        try 
        {
            list = bdao.ViewBookTitle(title);
        } catch (SQLException ex) 
        {
            list.add("Error in BookSevices:ViewBookIsbn"+ex.getMessage());
        }
        if(list.isEmpty())
        {
        list.add("No Book Found!");
        }
        return list;
        
    }
    
}
