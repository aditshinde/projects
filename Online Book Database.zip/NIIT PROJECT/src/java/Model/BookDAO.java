/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;



/**
 *
 * @author Adit Shinde
 */
public class BookDAO 
{
    List list = new LinkedList();
    DataSource ds = null;
    Connection cn = null;
    PreparedStatement st = null;
    ResultSet rs = null;
    boolean b=true;
    int rows=0;
    
        
    private static final String STMT1="SELECT * FROM BOOK";
    private static final String STMT2="INSERT INTO BOOK VALUES(?,?,?,?,?,?,?)";
    private static final String STMT3="DELETE FROM BOOK WHERE ISBN = ? OR TITLE = ?";
    private static final String STMT4="SELECT * FROM BOOK WHERE ISBN = ?";
    private static final String STMT5="SELECT * FROM BOOK WHERE TITLE = ?";
    
    
    public BookDAO() 
    {
        try
        {
           Context c = new InitialContext();
           if(c==null)
           {
               throw new RuntimeException("JNDI Context could not be found.");
           }
           ds = (DataSource)c.lookup("java:comp/env/ads");
           if(ds==null)
           {
               throw new RuntimeException("DataSource could not be found.");
           }
        } catch (NamingException ex) 
        {
            list.add("Naming Execption caught.");
        }
    }
    
//    public boolean ModifyBook(String str)
//    {
//        try 
//        {
//            cn=ds.getConnection();
//            st=cn.prepareStatement(STMT4);
//            st.setString(1, str);
//            st.setString(2, str);
//            st.executeUpdate();
//        } 
//        catch (SQLException ex) 
//        {
//            b=false;
//            Logger.getLogger(BookDAO.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return b;
//    }
    
    public boolean DeleteBook(String str)
    {
        try 
        {
            cn=ds.getConnection();
            st=cn.prepareStatement(STMT3);
            st.setString(1, str);
            st.setString(2, str);
            rows = st.executeUpdate();
            if(rows==1)
            {
                b=true;
            }
            else
            {
                b=false;
            }
        } 
        catch (SQLException ex) 
        {
            b=false;
            Logger.getLogger(BookDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return b;
    }
    
    
    
    public boolean CreateNewBook(String isbn,String title,String author,String pub,String dop,
            String price,String discnt)
    {
        try 
        {
            cn=ds.getConnection();
            st=cn.prepareStatement(STMT2);
            
            st.setString(1, isbn);
            st.setString(2, title);
            st.setString(3, author);
            st.setString(4, pub);
            st.setString(5, dop);
            st.setString(6, price);
            st.setString(7, discnt);
            
            st.executeUpdate();
        } 
        catch (SQLException ex) 
        {
            b=false;
            Logger.getLogger(BookDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return b;
    }
    
    
    public List ViewAll() throws SQLException
    {
               
        cn=ds.getConnection();
        st=cn.prepareStatement(STMT1);
        rs=st.executeQuery();
        
        while(rs.next())
        {
            BookData bd = new BookData(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
            list.add(bd);  
        }
        
        return list;
    }
    
    public List ViewBookIsbn(String isbn) throws SQLException
    {
        cn=ds.getConnection();
        st=cn.prepareStatement(STMT4);
        st.setString(1, isbn);
        rs=st.executeQuery();
        
        
        while(rs.next())
        {
            BookData bd = new BookData(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
            list.add(bd);  
        }
        
        return list;
        
    }        
    
    public List ViewBookTitle(String title) throws SQLException
    {
        cn=ds.getConnection();
        st=cn.prepareStatement(STMT5);
        st.setString(1, title);
        rs=st.executeQuery();
        
        while(rs.next())
        {
            BookData bd = new BookData(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
            list.add(bd);  
        }
        
        return list;
        
    }        
    
}
