/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Adit Shinde
 */
public class LoginServices 
{
    LoginData ld = new LoginData();
    LoginDAO ldao = new LoginDAO();
   
    boolean b;
    public LoginServices() 
    {
    }
    
    
    public String CheckLogin(String user,String pass,String type)
    { 
        try 
        {
           
            b = ldao.CheckLogin(user, pass, type);
            if(b==false)
                return "error";
            else
                return type;
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(LoginServices.class.getName()).log(Level.SEVERE, null, ex);
            return "error";
        }
    }
   
    public boolean CreateNewLogin(String user,String pass,String type) throws SQLException
    {
        b = ldao.CreateNewLogin(user,pass,type); 
        return b;
    }
}
