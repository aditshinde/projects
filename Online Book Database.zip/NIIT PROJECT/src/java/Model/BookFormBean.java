/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
 *
 * @author Adit Shinde
 */
public class BookFormBean extends ActionForm
{
    private String isbn;
    private String title;
    private String author;
    private String pub;
    private String dop;
    private String price;
    private String discnt;

    /**
     * @return the isbn
     */
    public String getIsbn() {
        return isbn;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @return the author
     */
    public String getAuthor() {
        return author;
    }

    /**
     * @return the pub
     */
    public String getPub() {
        return pub;
    }

    /**
     * @return the dop
     */
    public String getDop() {
        return dop;
    }

    /**
     * @return the price
     */
    public String getPrice() {
        return price;
    }

    /**
     * @return the discnt
     */
    public String getDiscnt() {
        return discnt;
    }

    /**
     * @param isbn the isbn to set
     */
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @param author the author to set
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * @param pub the pub to set
     */
    public void setPub(String pub) {
        this.pub = pub;
    }

    /**
     * @param dop the dop to set
     */
    public void setDop(String dop) {
        this.dop = dop;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(String price) {
        this.price = price;
    }

    /**
     * @param discnt the discnt to set
     */
    public void setDiscnt(String discnt) {
        this.discnt = discnt;
    }
    
    @Override
    public ActionErrors validate(ActionMapping mapping,HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
        
        if(isbn.equals(""))
        {
            errors.add("isbn",new ActionMessage("errors.isbn.required"));
        }
        if(title.equals(""))
        {
            errors.add("title",new ActionMessage("errors.title.required"));
        }
        if(author.equals(""))
        {
            errors.add("author",new ActionMessage("errors.author.required"));
        }
        try
        {
            int i = Integer.parseInt(price);
        }
        catch(NumberFormatException e)
        {
            errors.add("price",new ActionMessage("errors.integer"));
        }
        
        return errors;
    }
    
    
}
