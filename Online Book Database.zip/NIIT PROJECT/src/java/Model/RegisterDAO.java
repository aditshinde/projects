/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 *
 * @author Adit Shinde
 */
public class RegisterDAO {
    private static final String STMT1="INSERT INTO LOGIN VALUES (?,?,?)";
    private static final String STMT2="INSERT INTO REGISTRATIONS VALUES (?,?,?,?,?)";
  
    List list= new LinkedList();
    DataSource ds= null;
    Connection cn=null;
    PreparedStatement st=null;
    
    
    public RegisterDAO()  
    {
        try 
        {
            ds=getAds();
        } catch (NamingException ex) 
        {
            list.add("Naming Error in Registeration.");
        }
    }

        
    List CreateNewRegistration (String name,String eid,String add,String user,String pass)
    {
        try 
        {
            cn=ds.getConnection();
            st = cn.prepareStatement(STMT1);
            st.setString(1, user);
            st.setString(2, pass);
            st.setString(3, "0");
            st.executeUpdate();
                                   
            st = cn.prepareStatement(STMT2);
            st.setString(1, name);
            st.setString(2, eid);
            st.setString(3, add);
            st.setString(4, user);
            st.setString(5, pass);
            st.executeUpdate();
            
        }
        catch (SQLException ex) 
        {
            list.add("Error in creating new login.");
        }
        finally
        {
            try 
            {
                
                st.close();
                cn.close();
            } catch (SQLException ex) 
            {
                list.add("Connections could not be closed properly.");
            }
        }
        return list;
    }
    
    private DataSource getAds() throws NamingException {
        Context c = new InitialContext();
        return (DataSource) c.lookup("java:comp/env/ads");
    }
    
}
