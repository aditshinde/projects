/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author Adit Shinde
 */
public class BookData 
{
    private String isbn;
    private String title;
    private String author;
    private String pub;
    private String dop;
    private String price;
    private String discnt;

    /**
     * @return the isbn
     */
    public String getIsbn() {
        return isbn;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @return the author
     */
    public String getAuthor() {
        return author;
    }

    /**
     * @return the pub
     */
    public String getPub() {
        return pub;
    }

    /**
     * @return the dop
     */
    public String getDop() {
        return dop;
    }

    /**
     * @return the price
     */
    public String getPrice() {
        return price;
    }

    /**
     * @return the discnt
     */
    public String getDiscnt() {
        return discnt;
    }

    /**
     * @param isbn the isbn to set
     */
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @param author the author to set
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * @param pub the pub to set
     */
    public void setPub(String pub) {
        this.pub = pub;
    }

    /**
     * @param dop the dop to set
     */
    public void setDop(String dop) {
        this.dop = dop;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(String price) {
        this.price = price;
    }

    /**
     * @param discnt the discnt to set
     */
    public void setDiscnt(String discnt) {
        this.discnt = discnt;
    }

    public BookData() 
    {
        
    }

    public BookData(String isbn, String title, String author, String pub, String dop, String price, String discnt) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.pub = pub;
        this.dop = dop;
        this.price = price;
        this.discnt = discnt;
    }

    @Override
    public String toString() 
    {
        return "ISBN:" + isbn + "  Title:" + title + "  Author:" + author + "  Publisher:" + pub + "  Publishing Date:" + dop + "  Price:" + price + "  Discount:" + discnt;
    }
    
    
    
}
