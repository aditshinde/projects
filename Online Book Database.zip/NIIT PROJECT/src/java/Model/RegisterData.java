/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author Adit Shinde
 */
public class RegisterData 
{
    private String name;
    private String eid;
    private String add;
    private String user;
    private String pass;

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the eid
     */
    public String getEid() {
        return eid;
    }

    /**
     * @return the add
     */
    public String getAdd() {
        return add;
    }

    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * @return the pass
     */
    public String getPass() {
        return pass;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @param eid the eid to set
     */
    public void setEid(String eid) {
        this.eid = eid;
    }

    /**
     * @param add the add to set
     */
    public void setAdd(String add) {
        this.add = add;
    }

    /**
     * @param user the user to set
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * @param pass the pass to set
     */
    public void setPass(String pass) {
        this.pass = pass;
    }

    public RegisterData() {
    }

    public RegisterData(String name, String eid, String add, String user, String pass) {
        this.name = name;
        this.eid = eid;
        this.add = add;
        this.user = user;
        this.pass = pass;
    }

    
    
}
