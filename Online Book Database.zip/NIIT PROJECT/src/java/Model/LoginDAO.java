/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 *
 * @author Adit Shinde
 */
public class LoginDAO 
{
    private static final String STMT1="SELECT * FROM LOGIN WHERE USERNAME=? AND PASSWORD =? AND TYPE=?";
    private static final String STMT2="INSERT INTO LOGIN VALUES (?,?,?)";
    List list= new LinkedList();
    DataSource ds= null;
    Connection cn=null;
    PreparedStatement st=null;
    ResultSet rs=null;
    int num_of_rows=0;
    public LoginDAO() 
    {
        try 
        {
            ds=getAds();
        } catch (NamingException ex) 
        {
            list.add(ex);
        }
    }

    boolean CheckLogin (String user,String pass,String type) throws SQLException
    {
        
            cn = ds.getConnection();
            st = cn.prepareStatement(STMT1);
            st.setString(1, user);
            st.setString(2, pass);
            st.setString(3, type);
            rs = st.executeQuery();
            int i=0;
            while(rs.next())
            {
              i++;
            }
            rs.close();
            st.close();
            cn.close();
        //    LoginData ld = new LoginData(rs.getString(1),rs.getString(2),rs.getString(3));
            if(i==1)
            {
                return true;
            }
            else
            {
                return false;
            }            
            
            
    }
    
    boolean CreateNewLogin (String user,String pass,String type) throws SQLException
    {
        
            cn = ds.getConnection();
            st = cn.prepareStatement(STMT2);
            st.setString(1, user);
            st.setString(2, pass);
            st.setString(3, type);
            st.executeUpdate();
            
            st.close();
            cn.close();
            return true;         
    }
    
    private DataSource getAds() throws NamingException {
        Context c = new InitialContext();
        return (DataSource) c.lookup("java:comp/env/ads");
    }
    
    
}
