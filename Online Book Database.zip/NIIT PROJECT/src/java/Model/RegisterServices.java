/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Adit Shinde
 */
public class RegisterServices 
{
    List list = new LinkedList();
    RegisterDAO rdao = new RegisterDAO();
    
    public RegisterServices() 
    {
        
    }

    public List Register(String name,String eid,String add,String user,String pass) 
    {
        list = rdao.CreateNewRegistration(name, eid, add, user, pass);
        return list;
    }
    
    
}
